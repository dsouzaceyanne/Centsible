package com.example.budget

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.budget.data.Account
import com.google.firebase.database.*

class AccountsFragment : Fragment() {
    private lateinit var accountsRecyclerView: RecyclerView
    private lateinit var addAccountButton: Button
    private lateinit var noAccountsMessage: TextView
    private lateinit var accounts: MutableList<Account>
    private lateinit var accountAdapter: AccountAdapter
    private lateinit var database: DatabaseReference

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.accounts, container, false)

        accountsRecyclerView = view.findViewById(R.id.accountsRecyclerView)
        addAccountButton = view.findViewById(R.id.addAccountButton)
        noAccountsMessage = view.findViewById(R.id.noAccountsMessage)

        // Initialize the accounts list and adapter
        accounts = mutableListOf()
        accountAdapter = AccountAdapter(accounts) { account ->
            // Handle account click if needed (e.g., open details or edit)
        }

        // Set layout manager for the RecyclerView
        accountsRecyclerView.layoutManager = LinearLayoutManager(requireContext())
        accountsRecyclerView.adapter = accountAdapter

        // Initialize Firebase database reference
        database = FirebaseDatabase.getInstance().getReference("accounts")

        // Button to show the Bottom Sheet for adding a new account
        addAccountButton.setOnClickListener {
            // Show the BottomSheetFragment directly
            val bottomSheetFragment = AddAccountBottomSheet()
            bottomSheetFragment.show(childFragmentManager, bottomSheetFragment.tag)
        }

        // Load accounts from Firebase
        loadAccounts()

        return view
    }

    private fun loadAccounts() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                accounts.clear() // Clear the existing accounts list
                for (accountSnapshot in snapshot.children) {
                    val account = accountSnapshot.getValue(Account::class.java)
                    account?.let { accounts.add(it) } // Add the account to the list if not null
                }
                accountAdapter.notifyDataSetChanged() // Notify adapter of data changes

                // Update visibility based on the accounts list
                if (accounts.isEmpty()) {
                    noAccountsMessage.visibility = View.VISIBLE
                    accountsRecyclerView.visibility = View.GONE
                } else {
                    noAccountsMessage.visibility = View.GONE
                    accountsRecyclerView.visibility = View.VISIBLE
                }
            }

            override fun onCancelled(error: DatabaseError) {
                // Handle error (optional: log or show a message)
            }
        })
    }

    companion object {
        private const val REQUEST_CODE_ADD_ACCOUNT = 1
    }
}
