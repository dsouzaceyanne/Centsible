package com.example.budget.data

data class BudgetTransaction(
    val id: String = "",
    val amount: Double = 0.0,
    val isExpense: Boolean=false,
    val category: String = "",
    val accountName: String = "",
    val date: String = "",
    val time: String = ""
)
