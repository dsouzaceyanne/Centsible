package com.example.budget

import android.graphics.Color
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.TextView
import androidx.fragment.app.Fragment
import com.github.mikephil.charting.charts.PieChart
import com.github.mikephil.charting.data.PieData
import com.github.mikephil.charting.data.PieDataSet
import com.github.mikephil.charting.data.PieEntry
import com.google.firebase.database.*

class AnalysisFragment : Fragment() {

    private lateinit var pieChart: PieChart
    private lateinit var expenseBreakdown: LinearLayout
    private val db = FirebaseDatabase.getInstance().reference.child("transactions")

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        val view = inflater.inflate(R.layout.activity_analysis, container, false)

        pieChart = view.findViewById(R.id.pieChart)
        expenseBreakdown = view.findViewById(R.id.expenseBreakdown)

        fetchTransactionData()

        return view
    }

    private fun fetchTransactionData() {
        db.addListenerForSingleValueEvent(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                val categoryTotals = mutableMapOf<String, Float>()
                var totalExpenses = 0f

                Log.d("RealtimeData", "Documents retrieved: ${snapshot.childrenCount}")

                for (transactionSnapshot in snapshot.children) {
                    val category = transactionSnapshot.child("category").getValue(String::class.java) ?: "Other"
                    val amount = transactionSnapshot.child("amount").getValue(Float::class.java) ?: 0f
                    val isIncome = transactionSnapshot.child("income").getValue(Boolean::class.java) ?: false

                    if (amount > 0 && !isIncome) {
                        categoryTotals[category] = categoryTotals.getOrDefault(category, 0f) + amount
                        totalExpenses += amount
                    }
                }

                Log.d("RealtimeData", "Category Totals after calculation: $categoryTotals")
                Log.d("RealtimeData", "Total Expenses: $totalExpenses")

                if (totalExpenses > 0) {
                    setupPieChart(categoryTotals, totalExpenses)
                    setupProgressBars(categoryTotals, totalExpenses)
                } else {
                    Log.d("RealtimeData", "No expenses to display.")
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Log.e("RealtimeError", "Error getting documents: ${error.message}")
            }
        })
    }

    private fun setupPieChart(categoryTotals: Map<String, Float>, totalExpenses: Float) {
        val pieEntries = ArrayList<PieEntry>()
        val colors = ArrayList<Int>()

        for ((category, amount) in categoryTotals) {
            if (amount > 0) {
                pieEntries.add(PieEntry(amount, category))
                colors.add(Color.parseColor(getCategoryColor(category)))
            }
        }

        Log.d("PieChartData", "Pie Entries: $pieEntries")

        if (pieEntries.isEmpty()) {
            Log.d("PieChartData", "No entries to display in PieChart.")
            return
        }

        val dataSet = PieDataSet(pieEntries, "Expenses")
        dataSet.colors = colors
        dataSet.sliceSpace = 2f

        val pieData = PieData(dataSet)
        pieData.setValueTextSize(12f)
        pieData.setValueTextColor(Color.WHITE)

        pieChart.data = pieData
        pieChart.invalidate()
    }

    private fun setupProgressBars(categoryTotals: Map<String, Float>, totalExpenses: Float) {
        expenseBreakdown.removeAllViews()

        for ((category, amount) in categoryTotals) {
            val percentage = (amount / totalExpenses) * 100

            val row = LayoutInflater.from(requireContext()).inflate(R.layout.analysis_category_row, expenseBreakdown, false)
            val categoryText = row.findViewById<TextView>(R.id.categoryText)
            val amountText = row.findViewById<TextView>(R.id.amountText)
            val progressBar = row.findViewById<ProgressBar>(R.id.progressBar)

            categoryText.text = category
            amountText.text = String.format("₹%.2f (%.2f%%)", amount, percentage)
            progressBar.progress = percentage.toInt()

            expenseBreakdown.addView(row)
        }
    }

    private fun getCategoryColor(category: String): String {
        return when (category) {
            "Food" -> "#FF6A6A"
            "Shopping" -> "#FFC107"
            "Transportation" -> "#3F51B5"
            "Entertainment" -> "#9C27B0"
            "Bills" -> "#EC6B56"
            "Health" -> "#47B39C"
            "Education" -> "#72b4eb"
            "Home" -> "#cea9bc"
            "Gift" ->"#52D726"
            else -> "#732E00"
        }
    }
}
