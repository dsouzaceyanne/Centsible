package com.example.budget

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.widget.Button
import androidx.appcompat.app.AppCompatActivity

class Help : BaseActivity() {

    private lateinit var btnOpenContacts: Button
    private lateinit var btnSendEmail: Button
    private val specificPhoneNumber = "7483567636"  // Replace with the desired phone number
    private val specificEmail = "viyapinto@gmail.com"  // Replace with the desired email recipient

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.help)

        btnOpenContacts = findViewById(R.id.button_chat_support)
        btnSendEmail = findViewById(R.id.button2)

        // Load SharedPreferences to check if the contact button was clicked before
        val sharedPref = getSharedPreferences("ButtonClickPrefs", Context.MODE_PRIVATE)
        val contactClickedBefore = sharedPref.getBoolean("contact_clicked", false)

        // Set up button click listener for dialer
        btnOpenContacts.setOnClickListener {
            openDialer()

            // Save that the contact button was clicked
            sharedPref.edit().putBoolean("contact_clicked", true).apply()
        }

        // Set up button click listener for email
        btnSendEmail.setOnClickListener {
            openEmail()
        }
    }

    private fun openDialer() {
        // Create intent to open dialer with the specific number
        val intent = Intent(Intent.ACTION_DIAL)
        intent.data = Uri.parse("tel:$specificPhoneNumber")
        startActivity(intent)
    }

    private fun openEmail() {
        // Create intent to open email app with specific recipient
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:$specificEmail")
        }
        startActivity(intent)
    }
}
