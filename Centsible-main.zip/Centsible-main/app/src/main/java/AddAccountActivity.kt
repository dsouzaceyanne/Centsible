package com.example.budget

import com.example.budget.data.Account
import android.os.Bundle

import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.appcompat.app.AppCompatActivity
import com.google.firebase.database.*

class AddAccountActivity : AppCompatActivity() {
    private lateinit var accountNameEditText: EditText
    private lateinit var initialAmountEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button
    private lateinit var database: DatabaseReference

    // Variable to hold the selected icon resource ID
    private var selectedIconResId: Int = 0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.addacc)

        accountNameEditText = findViewById(R.id.accountName)
        initialAmountEditText = findViewById(R.id.initialAmount)
        saveButton = findViewById(R.id.saveButton)
        cancelButton = findViewById(R.id.cancelButton)

        // Initialize database reference
        database = FirebaseDatabase.getInstance().getReference("accounts")

        // Set up click listeners for icons
        setupIconSelection()

        saveButton.setOnClickListener {
            saveAccount()
        }

        cancelButton.setOnClickListener {
            finish() // Go back to AccountsActivity
        }
    }

    private fun setupIconSelection() {
        val iconContainer = findViewById<LinearLayout>(R.id.iconContainer)

        // Set click listeners for each icon
        for (i in 0 until iconContainer.childCount) {
            val iconImageView = iconContainer.getChildAt(i) as ImageView
            iconImageView.setOnClickListener {
                // Deselect all icons first
                deselectAllIcons(iconContainer)
                // Select the clicked icon
          // Add a drawable for selection
                selectedIconResId = getIconResourceId(iconImageView.id)
            }
        }
    }

    private fun deselectAllIcons(container: LinearLayout) {
        for (i in 0 until container.childCount) {
            val iconImageView = container.getChildAt(i) as ImageView
            iconImageView.setBackgroundResource(0) // Clear the background
        }
    }

    private fun getIconResourceId(iconId: Int): Int {
        return when (iconId) {
            R.id.icon10 -> R.drawable.cash
            R.id.icon7 -> R.drawable.visa
            R.id.icon8 -> R.drawable.card
            R.id.icon4 -> R.drawable.piggy
            R.id.icon2 -> R.drawable.master
            R.id.icon5 -> R.drawable.paypal
            R.id.icon6 -> R.drawable.wallet
            R.id.icon3 -> R.drawable.coin
            else -> 0 // Default icon or handle error
        }
    }

    private fun saveAccount() {
        val accountName = accountNameEditText.text.toString()
        val initialAmount = initialAmountEditText.text.toString().toDoubleOrNull() ?: 0.0

        if (accountName.isNotEmpty()) {
            // Create the account with selected icon
            val account = Account(name = accountName, balance = initialAmount, iconResId = selectedIconResId)
            val accountId = database.push().key ?: return // Get a new key for the account
            database.child(accountId).setValue(account).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    setResult(RESULT_OK)
                    finish() // Go back to AccountsActivity
                } else {
                    // Handle failure
                }
            }
        } else {
            // Show error message for empty account name
        }
    }
}
