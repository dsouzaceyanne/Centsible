package com.example.budget

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.budget.data.BudgetTransaction

class TransactionAdapter(private val transactionsByDate: Map<String, List<BudgetTransaction>>) :
    RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    private val transactionDates = transactionsByDate.keys.toList()
    private val VIEW_TYPE_HEADER = 0
    private val VIEW_TYPE_ITEM = 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        return when (viewType) {
            VIEW_TYPE_HEADER -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_date_header, parent, false)
                DateHeaderViewHolder(view)
            }
            VIEW_TYPE_ITEM -> {
                val view = LayoutInflater.from(parent.context).inflate(R.layout.item_transaction, parent, false)
                TransactionViewHolder(view)
            }
            else -> throw IllegalArgumentException("Invalid view type")
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        var currentPos = 0
        for (date in transactionDates) {
            if (currentPos == position) {
                if (holder is DateHeaderViewHolder) {
                    holder.bind(date)
                }
                return
            }
            currentPos++

            val transactionsForDate = transactionsByDate[date] ?: emptyList()
            for (transaction in transactionsForDate) {
                if (currentPos == position) {
                    if (holder is TransactionViewHolder) {
                        holder.bind(transaction)
                    }
                    return
                }
                currentPos++
            }
        }
    }

    override fun getItemCount(): Int {
        var itemCount = 0
        for (date in transactionDates) {
            itemCount++ // Header
            itemCount += transactionsByDate[date]?.size ?: 0 // Transactions
        }
        return itemCount
    }

    override fun getItemViewType(position: Int): Int {
        var currentPos = 0
        for (date in transactionDates) {
            if (currentPos == position) {
                return VIEW_TYPE_HEADER
            }
            currentPos++
            val transactionsForDate = transactionsByDate[date] ?: emptyList()
            if (position < currentPos + transactionsForDate.size) {
                return VIEW_TYPE_ITEM
            }
            currentPos += transactionsForDate.size
        }
        return -1
    }

    inner class DateHeaderViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val dateTextView: TextView = itemView.findViewById(R.id.text_transaction_date)

        fun bind(date: String) {
            dateTextView.text = date
        }
    }

    inner class TransactionViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val amountTextView: TextView = itemView.findViewById(R.id.text_transaction_amount)
        private val categoryTextView: TextView = itemView.findViewById(R.id.text_transaction_category)
        private val accountTextView: TextView = itemView.findViewById(R.id.text_transaction_account)
        private val categoryIcon: ImageView = itemView.findViewById(R.id.image_category_icon)

        fun bind(transaction: BudgetTransaction) {
            Log.d("TransactionAdapter", "Transaction ${transaction.id} isExpense: ${transaction.isExpense}")

            categoryTextView.text = transaction.category
            accountTextView.text = transaction.accountName

            // Determine sign and color based on isExpense
            val (sign, color) = if (transaction.isExpense) {
                "-" to ContextCompat.getColor(itemView.context, R.color.red)
            } else {
                "+" to ContextCompat.getColor(itemView.context, R.color.green)
            }

            // Set amount text with appropriate sign and color
            amountTextView.text = "$sign₹${transaction.amount}"
            amountTextView.setTextColor(color)

            // Set the category icon (keep existing code)
            val iconResId = when (transaction.category.lowercase()) {
                "food" -> R.drawable.food
                "shopping" -> R.drawable.shop
                "transportation" -> R.drawable.transport
                "entertainment" -> R.drawable.entertainment
                "bills" -> R.drawable.bills
                "health" -> R.drawable.health
                "education" -> R.drawable.education
                "home" -> R.drawable.home
                "gift" -> R.drawable.gift
                else -> R.drawable.cash
            }
            categoryIcon.setImageResource(iconResId)
        }
    }
}