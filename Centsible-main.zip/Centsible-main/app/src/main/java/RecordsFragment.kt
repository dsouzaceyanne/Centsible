package com.example.budget

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.firebase.database.*
import com.example.budget.data.BudgetTransaction
import java.text.SimpleDateFormat
import java.util.Locale
import java.util.Date

class RecordsFragment : Fragment() {
    private lateinit var transactionAdapter: TransactionAdapter
    private lateinit var transactionList: MutableList<BudgetTransaction>
    private lateinit var database: DatabaseReference
    private lateinit var recyclerView: RecyclerView  // Make recyclerView a class-level variable

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.records, container, false)

        // Initialize Firebase database reference for transactions
        database = FirebaseDatabase.getInstance().reference.child("transactions")

        // Initialize RecyclerView
        recyclerView = view.findViewById(R.id.recyclerView_transactions) // Reference RecyclerView here
        transactionList = mutableListOf()
        transactionAdapter = TransactionAdapter(emptyMap()) // Initially pass an empty map
        recyclerView.layoutManager = LinearLayoutManager(requireContext())
        recyclerView.adapter = transactionAdapter

        // Load transactions from Firebase
        loadTransactions()

        return view
    }

    private fun loadTransactions() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                transactionList.clear()
                for (data in snapshot.children) {
                    val transaction = data.getValue(BudgetTransaction::class.java)
                    transaction?.let {
                        // Handle missing date by setting a default date or skipping invalid entries
                        val validDate = if (it.date.isEmpty()) {
                            val currentTime = System.currentTimeMillis()
                            val formattedDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date(currentTime))
                            formattedDate  // Set current date if empty
                        } else {
                            it.date
                        }

                        val validTime = if (it.time.isEmpty()) {
                            System.currentTimeMillis().toString()  // Use current time as a fallback
                        } else {
                            it.time
                        }

                        // Ensure valid date before adding the transaction
                        if (validDate.isNotEmpty() && validDate.length >= 10) {
                            transactionList.add(it.copy(date = validDate, time = validTime))  // Update the transaction with valid date and time
                        } else {
                            Log.w("RecordsFragment", "Invalid date format for transaction: ${it.date}")
                        }
                    }
                }

                // Group transactions by date (ignoring time)
                val transactionsGroupedByDate = transactionList
                    .groupBy { it.date.substring(0, 10) }

                // Pass the grouped data to the adapter
                transactionAdapter = TransactionAdapter(transactionsGroupedByDate)
                recyclerView.adapter = transactionAdapter
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(requireContext(), "Failed to load transactions", Toast.LENGTH_SHORT).show()
            }
        })
    }

}
