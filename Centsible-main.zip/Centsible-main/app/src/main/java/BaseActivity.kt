package com.example.budget

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.navigation.NavigationView
import com.google.android.material.bottomnavigation.BottomNavigationView

open class BaseActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private lateinit var drawerLayout: DrawerLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_base) // Ensure your layout is correctly set
        // Initialize DrawerLayout
        drawerLayout = findViewById(R.id.drawer_layout)
        val navigationView = findViewById<NavigationView>(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener(this)

        // Initialize BottomNavigationView
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> {
                    Log.d("BaseActivity", "Navigating to MainActivity from Home")
                    startActivity(Intent(this, MainActivity::class.java))
                    finish() // Optional: finish BaseActivity if you don't want to return to it
                    true
                }
                R.id.budget -> {
                    Log.d("BaseActivity", "Navigating to MainActivity from Records")
                    startActivity(Intent(this, MainActivity::class.java))
                    finish() // Optional: finish BaseActivity if you don't want to return to it
                    true
                }
                R.id.accounts -> {
                    Log.d("BaseActivity", "Navigating to AccountsFragment")
                    loadFragment(AccountsFragment())
                    true
                }
                R.id.analysis -> {
                    Log.d("BaseActivity", "Navigating to AnalysisFragment")
                    loadFragment(AnalysisFragment())
                    true
                }
                else -> false
            }
        }

        // Set up drawer toggle for navigation drawer
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, R.string.open_nav,
            R.string.close_nav
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> {
                Log.d("BaseActivity", "Home selected - No action needed")
                // Optionally start a new activity if you want to navigate elsewhere
            }
            R.id.nav_profile -> {
                Log.d("BaseActivity", "Navigating to Profile Activity")
                startActivity(Intent(this, Profile::class.java))
            }
            R.id.nav_help -> {
                Log.d("BaseActivity", "Navigating to Help Activity")
                startActivity(Intent(this, Help::class.java))
            }
            R.id.nav_settings -> {
                Log.d("BaseActivity", "Settings Selected")
                showToast("Settings Selected")
            }
            R.id.nav_logout -> {
                Log.d("BaseActivity", "Logout Selected")
                showToast("Logout!")
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun loadFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
