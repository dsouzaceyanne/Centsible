package com.example.budget.data

import com.example.budget.R
import java.util.UUID

data class Account(
    var id: String = "", // Optional if you're using Firebase to generate IDs
    var name: String = "",
    var type: String = "default",
    var balance: Double = 0.0,
    var iconType: String = "default_icon",
    var iconResId: Int = 0 // Default to 0 or your default drawable ID
) {
    // No-argument constructor is created automatically by default values
    // but you can also explicitly define it like this:
    constructor() : this("", "", "default", 0.0, "default_icon", 0)
}


