package com.example.budget

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageButton
import androidx.fragment.app.Fragment
import androidx.fragment.app.FragmentTransaction
import androidx.navigation.fragment.findNavController

class HomeFragment : Fragment() {
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val view = inflater.inflate(R.layout.activity_home, container, false)

        // Find the buttons
        val addBudgetButton = view.findViewById<ImageButton>(R.id.addBudgetButton)
        val addAccountButton = view.findViewById<ImageButton>(R.id.addAccountButton)
        val addExpenseButton = view.findViewById<ImageButton>(R.id.addExpenseButton)


        // Set onClick listeners for navigation
        addBudgetButton.setOnClickListener {
            Log.d("HomeFragment", "Navigating to AnalysisFragment")
            loadFragment(AnalysisFragment())
        }


        addAccountButton.setOnClickListener {
            Log.d("HomeFragment", "Navigating to AccountsFragment")
            loadFragment(AccountsFragment())
        }

        addExpenseButton.setOnClickListener {
            Log.d("HomeFragment", "Navigating to ExpenseActivity")
            val intent = Intent(requireContext(), ExpenseActivity::class.java)
            startActivity(intent)
        }

        return view
    }

    // Helper function to load a fragment programmatically
    private fun loadFragment(fragment: Fragment) {
        parentFragmentManager.beginTransaction()
            .replace(R.id.fragment_container, fragment)
            .addToBackStack(null)
            .setTransition(FragmentTransaction.TRANSIT_FRAGMENT_FADE)
            .commit()
    }
}
