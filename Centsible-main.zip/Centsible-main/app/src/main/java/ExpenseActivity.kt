package com.example.budget

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import java.text.SimpleDateFormat
import android.os.Bundle
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.budget.data.Account
import com.example.budget.data.BudgetTransaction
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.firebase.database.*
import java.util.*

class ExpenseActivity : AppCompatActivity() {

    private lateinit var amountDisplay: TextView
    private lateinit var database: DatabaseReference
    private lateinit var accountDatabase: DatabaseReference
    private var isExpense = true
    private var operand = "0"
    private var selectedCategory = ""
    private var selectedAccount = ""
    private var selectedDate = ""
    private var selectedTime = ""
    private lateinit var accountList: MutableList<Account>
    private lateinit var dateButton: Button
    private lateinit var timeButton: Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_expense_entry)

        database = FirebaseDatabase.getInstance().reference.child("transactions")
        accountDatabase = FirebaseDatabase.getInstance().reference.child("accounts")

        amountDisplay = findViewById(R.id.amount_display)
        val radioIncome: RadioButton = findViewById(R.id.radio_income)
        val radioExpense: RadioButton = findViewById(R.id.radio_expense)
        val categoryButton: Button = findViewById(R.id.button_category)
        val saveButton: Button = findViewById(R.id.save_button)
        val cancelButton: Button = findViewById(R.id.cancel_button)
        val accountButton: Button = findViewById(R.id.button_account)
        dateButton = findViewById(R.id.date_text)
        timeButton = findViewById(R.id.time_text)

        dateButton.setOnClickListener { showDatePicker() }
        timeButton.setOnClickListener { showTimePicker() }
        cancelButton.setOnClickListener { finish() }

        accountList = mutableListOf()
        amountDisplay.text = "0"

        radioIncome.setOnCheckedChangeListener { _, isChecked -> isExpense = isChecked }
        radioExpense.setOnCheckedChangeListener { _, isChecked -> isExpense = !isChecked }

        categoryButton.setOnClickListener { showCategoryBottomSheet(if (isExpense) R.layout.category else R.layout.categoryincome) }
        accountButton.setOnClickListener { showAccountBottomSheet() }
        saveButton.setOnClickListener { saveTransaction() }

        setupCalculatorButtons()
        loadAccounts()
    }

    private fun showDatePicker() {
        val calendar = Calendar.getInstance()
        val datePicker = DatePickerDialog(this, { _, year, month, dayOfMonth ->
            val selectedCalendar = Calendar.getInstance()
            selectedCalendar.set(year, month, dayOfMonth)
            val format = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault())
            selectedDate = format.format(selectedCalendar.time)
            dateButton.text = selectedDate
        }, calendar.get(Calendar.YEAR), calendar.get(Calendar.MONTH), calendar.get(Calendar.DAY_OF_MONTH))
        datePicker.show()
    }

    private fun showTimePicker() {
        val calendar = Calendar.getInstance()
        val timePicker = TimePickerDialog(this, { _, hourOfDay, minute ->
            val selectedCalendar = Calendar.getInstance()
            selectedCalendar.set(Calendar.HOUR_OF_DAY, hourOfDay)
            selectedCalendar.set(Calendar.MINUTE, minute)
            val format = SimpleDateFormat("HH:mm", Locale.getDefault())
            selectedTime = format.format(selectedCalendar.time)
            timeButton.text = selectedTime
        }, calendar.get(Calendar.HOUR_OF_DAY), calendar.get(Calendar.MINUTE), true)
        timePicker.show()
    }

    private fun loadAccounts() {
        accountDatabase.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                accountList.clear()
                for (accountSnapshot in snapshot.children) {
                    val account = accountSnapshot.getValue(Account::class.java)
                    account?.let { accountList.add(it) }
                }
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ExpenseActivity, "Failed to load accounts", Toast.LENGTH_SHORT).show()
            }
        })
    }

    private fun showAccountBottomSheet() {
        val bottomSheetDialog = BottomSheetDialog(this)
        val bottomSheetView = layoutInflater.inflate(R.layout.bottom_sheet_account, null)

        val accountAdapter = AccountAdapter(accountList) { account ->
            selectedAccount = account.name
            bottomSheetDialog.dismiss()
        }

        val recyclerView = bottomSheetView.findViewById<RecyclerView>(R.id.accountRecyclerView)
        recyclerView.layoutManager = LinearLayoutManager(this)
        recyclerView.adapter = accountAdapter

        bottomSheetDialog.setContentView(bottomSheetView)
        bottomSheetDialog.show()
    }

    private fun showCategoryBottomSheet(layout: Int) {
        val bottomSheetDialog = BottomSheetDialog(this)
        val bottomSheetView = layoutInflater.inflate(layout, null)
        bottomSheetDialog.setContentView(bottomSheetView)

        val categories = mapOf(
            R.id.category_transportation to "Transportation",
            R.id.category_health to "Health",
            R.id.category_education to "Education",
            R.id.category_home to "Home",
            R.id.category_gift to "Gift",
            R.id.category_shopping to "Shopping",
            R.id.category_food to "Food",
            R.id.category_bills to "Bills",
            R.id.category_entertainment to "Entertainment",
            R.id.category_salary to "Salary",
            R.id.category_rental to "Rental",
            R.id.category_awards to "Awards",
            R.id.category_grants to "Grants",
            R.id.category_lottery to "Lottery",
            R.id.category_refunds to "Refunds"
        )

        for ((id, category) in categories) {
            bottomSheetView.findViewById<LinearLayout>(id)?.setOnClickListener {
                selectedCategory = category
                Toast.makeText(this, "Selected: $category", Toast.LENGTH_SHORT).show()
                bottomSheetDialog.dismiss()
            }
        }

        bottomSheetDialog.show()
    }

    private fun saveTransaction() {
        val transactionId = UUID.randomUUID().toString()
        val amount = amountDisplay.text.toString().toDoubleOrNull() ?: 0.0

        if (amount <= 0 || selectedCategory.isEmpty() || selectedAccount.isEmpty()) {
            Toast.makeText(this, "Enter a valid amount, category, and account", Toast.LENGTH_SHORT).show()
            return
        }

        // Determine if the transaction is an income or expense
        val isIncome = !isExpense

        val transaction = BudgetTransaction(
            id = transactionId,
            amount = amount,
            isExpense = isExpense,  // Set isExpense based on the radio button value
            category = selectedCategory,
            accountName = selectedAccount,
            date = selectedDate,
            time = selectedTime
        )

        database.child(transactionId).setValue(transaction)
            .addOnSuccessListener {
                Toast.makeText(this, "Transaction saved", Toast.LENGTH_SHORT).show()
                resetFields()
                loadTransactions()
            }
            .addOnFailureListener {
                Toast.makeText(this, "Failed to save transaction", Toast.LENGTH_SHORT).show()
            }
    }


    private fun resetFields() {
        amountDisplay.text = "0"
        operand = "0"
        selectedCategory = ""
        selectedAccount = ""
    }

    private fun setupCalculatorButtons() {
        val digitButtons = listOf(
            findViewById<Button>(R.id.btn_0), findViewById(R.id.btn_1), findViewById(R.id.btn_2),
            findViewById(R.id.btn_3), findViewById(R.id.btn_4), findViewById(R.id.btn_5),
            findViewById(R.id.btn_6), findViewById(R.id.btn_7), findViewById(R.id.btn_8), findViewById(R.id.btn_9),
            findViewById(R.id.btn_dot)
        )

        val btnAdd: Button = findViewById(R.id.btn_add)
        val btnSubtract: Button = findViewById(R.id.btn_subtract)
        val btnMultiply: Button = findViewById(R.id.btn_multiply)
        val btnDivide: Button = findViewById(R.id.btn_divide)
        val btnEquals: Button = findViewById(R.id.btn_equals)
        val btnBackspace: Button = findViewById(R.id.btn_backspace)

        val digitListener = View.OnClickListener { v ->
            val btn = v as Button
            appendToOperand(btn.text.toString())
        }

        digitButtons.forEach { it.setOnClickListener(digitListener) }
        btnAdd.setOnClickListener { setOperator("+") }
        btnSubtract.setOnClickListener { setOperator("-") }
        btnMultiply.setOnClickListener { setOperator("×") }
        btnDivide.setOnClickListener { setOperator("÷") }
        btnEquals.setOnClickListener { calculateResult() }
        btnBackspace.setOnClickListener { backspace() }
    }

    private fun appendToOperand(value: String) {
        operand = if (operand == "0" && value != ".") value else operand + value
        amountDisplay.text = operand
    }

    private fun setOperator(op: String) {
        if (operand.isNotEmpty() && !operand.endsWith(" ")) {
            operand += " $op "
            amountDisplay.text = operand
        }
    }

    private fun calculateResult() {
        val tokens = operand.split(" ")
        if (tokens.size == 3) {
            val num1 = tokens[0].toDoubleOrNull()
            val op = tokens[1]
            val num2 = tokens[2].toDoubleOrNull()

            if (num1 != null && num2 != null) {
                val result = when (op) {
                    "+" -> num1 + num2
                    "-" -> num1 - num2
                    "×" -> num1 * num2
                    "÷" -> if (num2 != 0.0) num1 / num2 else Double.NaN
                    else -> null
                }
                amountDisplay.text = result?.toString() ?: "Error"
                operand = result?.toString() ?: "0"
            }
        }
    }

    private fun backspace() {
        operand = if (operand.isNotEmpty()) operand.dropLast(1) else "0"
        amountDisplay.text = if (operand.isEmpty()) "0" else operand
    }

    private fun loadTransactions() {
        database.addValueEventListener(object : ValueEventListener {
            override fun onDataChange(snapshot: DataSnapshot) {
                // Logic to update RecyclerView with transaction data
            }

            override fun onCancelled(error: DatabaseError) {
                Toast.makeText(this@ExpenseActivity, "Failed to load transactions", Toast.LENGTH_SHORT).show()
            }
        })
    }
}
