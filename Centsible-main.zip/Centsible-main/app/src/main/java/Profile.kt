package com.example.budget

import android.Manifest
import android.app.DatePickerDialog
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.net.Uri
import android.os.Bundle
import android.provider.MediaStore
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.*

class Profile : BaseActivity() {

    private lateinit var usernameField: TextView
    private lateinit var emailField: TextView
    private lateinit var dobDisplay: TextView
    private lateinit var dobButton: Button
    private lateinit var profileImage: ImageView
    private lateinit var updateProfileButton: Button
    private lateinit var extraButton: Button

    private val PICK_IMAGE_REQUEST = 1
    private val CAMERA_REQUEST = 2

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.profile)

        // Initialize Views
        usernameField = findViewById(R.id.usernameField)
        emailField = findViewById(R.id.emailField)
        dobDisplay = findViewById(R.id.dobDisplay)
        dobButton = findViewById(R.id.dobButton)
        profileImage = findViewById(R.id.profileImage) // Assuming profileImage is the ImageView for the profile picture
        extraButton = findViewById(R.id.extraButton)

        // Check permissions
        checkPermissions()

        // Set initial text for display-only fields
        usernameField.text = "Username"
        emailField.text = "Email"

        // DatePicker for DOB selection
        dobButton.setOnClickListener {
            val calendar = Calendar.getInstance()
            val year = calendar.get(Calendar.YEAR)
            val month = calendar.get(Calendar.MONTH)
            val day = calendar.get(Calendar.DAY_OF_MONTH)

            val datePickerDialog = DatePickerDialog(this, { _, selectedYear, selectedMonth, selectedDay ->
                val date = "$selectedDay/${selectedMonth + 1}/$selectedYear"
                dobDisplay.text = date
            }, year, month, day)
            datePickerDialog.show()
        }

        // Set up the button click listener to open gallery or camera
        extraButton.setOnClickListener {
            // Show options to pick from gallery or camera
            val options = arrayOf("Gallery", "Camera")
            val builder = AlertDialog.Builder(this)
            builder.setTitle("Select Image Source")
            builder.setItems(options) { dialog, which ->
                when (which) {
                    0 -> openGallery()
                    1 -> openCamera()
                }
            }
            builder.show()
        }
    }

    private fun checkPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.CAMERA, Manifest.permission.WRITE_EXTERNAL_STORAGE), CAMERA_REQUEST)
        }
    }

    private fun openGallery() {
        val intent = Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI)
        startActivityForResult(intent, PICK_IMAGE_REQUEST)
    }

    private fun openCamera() {
        val intent = Intent(MediaStore.ACTION_IMAGE_CAPTURE)
        startActivityForResult(intent, CAMERA_REQUEST)
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode == RESULT_OK) {
            when (requestCode) {
                PICK_IMAGE_REQUEST -> {
                    val imageUri: Uri? = data?.data
                    profileImage.setImageURI(imageUri) // Set the selected image to the ImageView
                }
                CAMERA_REQUEST -> {
                    val imageBitmap = data?.extras?.get("data") as Bitmap
                    profileImage.setImageBitmap(imageBitmap) // Set the captured image to the ImageView
                }
            }
        }
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == CAMERA_REQUEST) {
            if ((grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED)) {
                // Permission granted, you can open the camera now
            } else {
                // Permission denied, show a message to the user
            }
        }
    }
}
