package com.example.budget

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.LinearLayout
import androidx.fragment.app.Fragment
import com.google.firebase.database.*
import com.example.budget.data.Account
import com.google.android.material.bottomsheet.BottomSheetDialogFragment

class AddAccountBottomSheet : BottomSheetDialogFragment() {
    private lateinit var accountNameEditText: EditText
    private lateinit var initialAmountEditText: EditText
    private lateinit var saveButton: Button
    private lateinit var cancelButton: Button
    private lateinit var database: DatabaseReference

    private var selectedIconResId: Int = 0

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the bottom sheet layout
        val view = inflater.inflate(R.layout.addacc, container, false)

        // Initialize the views
        accountNameEditText = view.findViewById(R.id.accountName)
        initialAmountEditText = view.findViewById(R.id.initialAmount)
        saveButton = view.findViewById(R.id.saveButton)
        cancelButton = view.findViewById(R.id.cancelButton)

        // Initialize Firebase database reference
        database = FirebaseDatabase.getInstance().getReference("accounts")

        // Setup the icon selection
        setupIconSelection(view)

        // Set click listeners
        saveButton.setOnClickListener {
            saveAccount()
        }

        cancelButton.setOnClickListener {
            dismiss() // Close the Bottom Sheet
        }

        return view
    }

    private fun setupIconSelection(view: View) {
        val iconContainer = view.findViewById<LinearLayout>(R.id.iconContainer)

        // Ensure that iconContainer is not null and iterate over its children
        iconContainer?.let { container ->
            for (i in 0 until container.childCount) {
                val iconImageView = container.getChildAt(i) as ImageView
                iconImageView.setOnClickListener {
                    deselectAllIcons(container)
                    selectedIconResId = getIconResourceId(iconImageView.id)
                }
            }
        }
    }

    private fun deselectAllIcons(container: LinearLayout) {
        for (i in 0 until container.childCount) {
            val iconImageView = container.getChildAt(i) as ImageView
            iconImageView.setBackgroundResource(0) // Clear any background
        }
    }

    private fun getIconResourceId(iconId: Int): Int {
        return when (iconId) {
            R.id.icon10 -> R.drawable.cash
            R.id.icon7 -> R.drawable.visa
            R.id.icon8 -> R.drawable.card
            R.id.icon4 -> R.drawable.piggy
            R.id.icon2 -> R.drawable.master
            R.id.icon5 -> R.drawable.paypal
            R.id.icon6 -> R.drawable.wallet
            R.id.icon3 -> R.drawable.coin
            else -> 0
        }
    }

    private fun saveAccount() {
        val accountName = accountNameEditText.text.toString()
        val initialAmount = initialAmountEditText.text.toString().toDoubleOrNull() ?: 0.0

        if (accountName.isNotEmpty()) {
            val account = Account(name = accountName, balance = initialAmount, iconResId = selectedIconResId)
            val accountId = database.push().key ?: return
            database.child(accountId).setValue(account).addOnCompleteListener { task ->
                if (task.isSuccessful) {
                    dismiss() // Close the Bottom Sheet
                } else {
                    // Handle failure
                }
            }
        } else {
            // Show error message for empty account name
        }
    }
}
