package com.example.budget

import android.content.Intent
import android.os.Bundle
import android.util.Log
import android.view.MenuItem
import android.widget.ImageButton
import android.widget.Toast
import androidx.appcompat.app.ActionBarDrawerToggle
import androidx.appcompat.app.AppCompatActivity
import androidx.appcompat.widget.Toolbar
import androidx.core.view.GravityCompat
import androidx.drawerlayout.widget.DrawerLayout
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.navigation.NavigationView
import com.google.firebase.auth.FirebaseAuth

class MainActivity : AppCompatActivity(), NavigationView.OnNavigationItemSelectedListener {
    private lateinit var drawerLayout: DrawerLayout
    private lateinit var firebaseAuth: FirebaseAuth

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        firebaseAuth = FirebaseAuth.getInstance()

        // Check if the user is logged in
        if (firebaseAuth.currentUser == null) {
            val intent = Intent(this, SignInActivity::class.java)
            startActivity(intent)
            finish()
        }

        // Set the toolbar as the ActionBar
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        setSupportActionBar(toolbar)

        // Initialize DrawerLayout
        drawerLayout = findViewById(R.id.drawer_layout)
        val navigationView = findViewById<NavigationView>(R.id.nav_view)
        navigationView.setNavigationItemSelectedListener(this)

        // Initialize BottomNavigationView
        val bottomNavigationView = findViewById<BottomNavigationView>(R.id.bottomNavigationView)
        bottomNavigationView.setOnItemSelectedListener { item ->
            when (item.itemId) {
                R.id.home -> {
                    Log.d("MainActivity", "Home selected - No action needed")
                    loadFragment(HomeFragment())
                    true
                }
                R.id.budget -> {
                    Log.d("MainActivity", "Navigating to RecordsFragment")
                    loadFragment(RecordsFragment())
                    true
                }
                R.id.accounts -> {
                    Log.d("MainActivity", "Navigating to AccountsFragment")
                    loadFragment(AccountsFragment())
                    true
                }
                R.id.analysis -> {
                    Log.d("MainActivity", "Navigating to AnalysisFragment")
                    loadFragment(AnalysisFragment())
                    true
                }
                else -> false
            }
        }

        // Set up button to navigate to ExpenseActivity
        val addButton: ImageButton = findViewById(R.id.add_transaction_button)
        addButton.setOnClickListener {
            startActivity(Intent(this, ExpenseActivity::class.java))
        }

        // Set up drawer toggle for navigation drawer
        val toggle = ActionBarDrawerToggle(
            this, drawerLayout, toolbar, R.string.open_nav, R.string.close_nav
        )
        drawerLayout.addDrawerListener(toggle)
        toggle.syncState()
    }

    override fun onNavigationItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.nav_home -> {
                Log.d("MainActivity", "Home selected - No action needed")
            }
            R.id.nav_profile -> {
                Log.d("MainActivity", "Navigating to Profile Activity")
                startActivity(Intent(this, Profile::class.java))
            }
            R.id.nav_help -> {
                Log.d("MainActivity", "Navigating to Help Activity")
                startActivity(Intent(this, Help::class.java))
            }
            R.id.nav_settings -> {
                Log.d("MainActivity", "Settings Selected")
                showToast("Settings Selected")
            }
            R.id.nav_logout -> {
                Log.d("MainActivity", "Logout Selected")
                firebaseAuth.signOut()  // Sign out the user
                startActivity(Intent(this, SignInActivity::class.java))
                finish()
            }
        }
        drawerLayout.closeDrawer(GravityCompat.START)
        return true
    }

    private fun loadFragment(fragment: Fragment) {
        val transaction = supportFragmentManager.beginTransaction()
        transaction.replace(R.id.fragment_container, fragment)
        transaction.addToBackStack(null)
        transaction.commit()
    }

    private fun showToast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

    override fun onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START)
        } else {
            super.onBackPressed()
        }
    }
}
