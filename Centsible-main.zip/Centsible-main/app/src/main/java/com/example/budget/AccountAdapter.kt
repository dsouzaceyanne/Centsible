package com.example.budget

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.RecyclerView
import com.example.budget.data.Account

class AccountAdapter(
    private val accounts: MutableList<Account>, // Change to MutableList for updating
    private val onAccountClick: (Account) -> Unit
) : RecyclerView.Adapter<AccountAdapter.AccountViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): AccountViewHolder {
        val view = LayoutInflater.from(parent.context)
            .inflate(R.layout.item_accounts, parent, false)
        return AccountViewHolder(view)
    }

    override fun onBindViewHolder(holder: AccountViewHolder, position: Int) {
        holder.bind(accounts[position])
    }

    override fun getItemCount(): Int = accounts.size

    inner class AccountViewHolder(itemView: View) : RecyclerView.ViewHolder(itemView) {
        private val accountIcon: ImageView = itemView.findViewById(R.id.accountIcon)
        private val accountNameTextView: TextView = itemView.findViewById(R.id.accountName)
        private val accountBalanceTextView: TextView = itemView.findViewById(R.id.accountBalance)

        fun bind(account: Account) {
            // Set account icon
            account.iconResId?.let {
                accountIcon.setImageResource(it) // Use the iconResId from Account
            }

            // Set account name
            accountNameTextView.text = account.name

            // Format the balance and set it
            accountBalanceTextView.text = String.format(
                itemView.context.getString(R.string.account_balance_format),
                account.balance
            )

            // Set balance color based on value (red for negative, green for positive)
            accountBalanceTextView.setTextColor(
                ContextCompat.getColor(
                    itemView.context,
                    if (account.balance < 0) R.color.red else R.color.green
                )
            )

            // Set click listener
            itemView.setOnClickListener { onAccountClick(account) }
        }
    }

    // Method to update accounts
    fun updateAccounts(newAccounts: List<Account>) {
        accounts.clear() // Clear current list
        accounts.addAll(newAccounts) // Add the new list
        notifyDataSetChanged() // Notify the adapter that data has changed
    }
}
