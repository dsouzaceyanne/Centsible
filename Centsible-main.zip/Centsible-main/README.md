# Centsible

Centsible is a sleek and intuitive budget tracking application developed using Kotlin for Android and Firebase for backend services and authentication. It helps users efficiently monitor their income, spending, and savings — all in one place. For deeper financial analysis, Matplotlib is used to generate custom visualizations.


##  Features

- **Firebase Authentication** – Secure login and registration.
- **Expense Management** – Record, edit, and categorize daily transactions.
- **Multiple Accounts** – Manage multiple wallets, cards, or bank accounts.
- **Analytics Dashboard** – Visual summaries with:
  - In-app charts using **MPAndroidChart**
  - Backend-driven plots using **Matplotlib**
- **Cloud Sync** – Real-time updates via Firebase Firestore.
- **Budget Goals** – Set monthly spending limits and get notified when close to exceeding.
- **Search and Filter** – View transactions by category, date, or amount.


## Tech Stack

| Layer         | Technology               |
|---------------|---------------------------|
| Frontend      | Kotlin (Android)          |
| Backend       | Firebase (Auth, Firestore)|
| Visualization | MPAndroidChart, Matplotlib|
| Data Export   | Matplotlib (for PDFs/PNGs)|

---


 Getting Started

 Prerequisites

- Android Studio
- Firebase Project
- Python 3.x (for Matplotlib reports)
- Kotlin 1.6+
- Required libraries:
  - `matplotlib`
  - `pandas`
  - `firebase-admin` *(if using Python backend scripts)*


